
  # Mobile VPN Capture App

  This is a code bundle for Mobile VPN Capture App. The original project is available at https://www.figma.com/design/yOJrnYJZhmRmBXSn4sTA5X/Mobile-VPN-Capture-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  